
<!DOCTYPE html>
<html> 
    <head>
       <title>CPMS</title>
         <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
         <link rel="stylesheet" type="text/css" href="css/style.css">
         <script src="js/jquery-3.3.1.min.js"></script>
         <script type="text/javascript" src="js/bootstrap.js"></script> 
         
    </head> 
    <body background="images/a2.jpg">
    
        <center>
            <div class="container " id="top" style="background-image: url(images/a4.jpg);">
                <div class="row-lg-6">
                    <h1>Car Parking Management System</h1>
                    <a href="#"><img src="images/slot.jpg" alt="CPMS" id="home_main_img"></a>
                </div>
            </div>
